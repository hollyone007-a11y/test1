# BuildPay — Codex Task Prompt

## Контекст проекта

Сайт: `http://pokladna.kvalitne.cz`  
Стек: PHP 8.4 API + vanilla JS SPA + MySQL (webzdarma.cz хостинг)  
Локальный путь: `C:\Users\huquf\Documents\Codex\2026-05-16\webzdarma-cz`  
Deploy: `powershell -ExecutionPolicy Bypass -File .\deploy-webzdarma.ps1 -RemoteRoot /web`

**Сначала прочитай:** `PROJECT_STATE.md`  
**Проверка JS:** `node --check www\assets\js\app.js`  
**После изменений:** деплой командой выше.

---

## Задачи (выполнять по порядку)

### ЗАДАЧА 1 — Новый дизайн: применить новый `app.css`

Заменить `www/assets/css/app.css` новым файлом из `design/app.css` (уже подготовлен с новой дизайн-системой).  
Ключевые изменения в новом CSS:
- Новые CSS-переменные: `--bg: #080b11`, `--accent: #1fd99a`, `--shadow-card`, `--radius: 10px`
- Сайдбар: разделитель после лого, active nav с зелёным фоном `rgba(31,217,154,.10)`
- Карточки `.card`, `.stat` — радиус 14px, тень через `--shadow-card`
- Кнопки — transition на hover, focus ring на инпутах
- Новые утилиты: `.chip`, `.avatar`, `.skeleton`, `.live-dot`, `.progress-bar`, `.feed-item`, `.offline-banner`, `.quick-action-btn`, `.doc-expiry-warn`

---

### ЗАДАЧА 2 — Service Worker: push-уведомления на телефон

**Файл:** `www/sw.js`

Добавить в `sw.js` полноценную обработку push-уведомлений:

```javascript
// В sw.js добавить после существующих addEventListener:

self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const title = data.title || 'BuildPay';
  const options = {
    body: data.body || '',
    icon: '/assets/icons/buildpay-192.png',
    badge: '/assets/icons/buildpay-badge-96.png',
    tag: data.tag || 'buildpay-notif',
    renotify: true,
    requireInteraction: data.requireInteraction || false,
    data: { url: data.url || '/' },
    vibrate: [200, 100, 200],
    actions: data.actions || [],
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windows => {
      const existing = windows.find(c => c.url.includes(self.location.origin));
      return existing ? existing.focus().then(w => w.navigate(url)) : clients.openWindow(url);
    })
  );
});

self.addEventListener('pushsubscriptionchange', event => {
  event.waitUntil(
    self.registration.pushManager.subscribe(event.oldSubscription.options)
      .then(sub => fetch('/api/push/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sub.toJSON()),
        credentials: 'include',
      }))
  );
});
```

Обновить `CACHE_NAME` и версию в `SHELL` на текущую дату деплоя.

---

### ЗАДАЧА 3 — БД: таблица push_subscriptions

**Файл:** `www/schema.sql` — добавить миграцию:

```sql
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  employee_id INT UNSIGNED NULL,
  endpoint TEXT NOT NULL,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  user_agent VARCHAR(255) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_push_endpoint (endpoint(500)),
  KEY idx_push_user (user_id),
  CONSTRAINT fk_push_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

---

### ЗАДАЧА 4 — API: push-подписка и отправка уведомлений

**Новый файл:** `www/api/routes/push.php`

```php
<?php
declare(strict_types=1);

$method = request_method();
$parts = explode('/', request_path());
$action = $parts[1] ?? '';

// POST /api/push/subscribe — сохранить подписку
if ($method === 'POST' && $action === 'subscribe') {
    $user = require_auth();
    $data = read_json();
    if (empty($data['endpoint']) || empty($data['keys']['p256dh']) || empty($data['keys']['auth'])) {
        json_response(['ok' => false, 'error' => 'Invalid subscription'], 422);
    }
    $stmt = db()->prepare("
        INSERT INTO push_subscriptions (user_id, employee_id, endpoint, p256dh, auth, user_agent)
        VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            p256dh = VALUES(p256dh),
            auth = VALUES(auth),
            user_agent = VALUES(user_agent),
            updated_at = NOW()
    ");
    $stmt->execute([
        (int)$user['id'],
        !empty($user['employee_id']) ? (int)$user['employee_id'] : null,
        (string)$data['endpoint'],
        (string)$data['keys']['p256dh'],
        (string)$data['keys']['auth'],
        substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
    ]);
    audit_log($user, 'PUSH_SUBSCRIBE', 'push', (int)db()->lastInsertId());
    json_response(['ok' => true]);
}

// DELETE /api/push/subscribe — удалить подписку
if ($method === 'DELETE' && $action === 'subscribe') {
    $user = require_auth();
    $data = read_json();
    if (!empty($data['endpoint'])) {
        db()->prepare("DELETE FROM push_subscriptions WHERE user_id = ? AND endpoint = ?")
            ->execute([(int)$user['id'], (string)$data['endpoint']]);
    }
    json_response(['ok' => true]);
}

// GET /api/push/vapid-public — вернуть публичный VAPID ключ
if ($method === 'GET' && $action === 'vapid-public') {
    require_auth();
    $key = defined('VAPID_PUBLIC_KEY') ? VAPID_PUBLIC_KEY : '';
    if (!$key) json_response(['ok' => false, 'error' => 'VAPID not configured'], 503);
    json_response(['ok' => true, 'key' => $key]);
}

json_response(['ok' => false, 'error' => 'Not found'], 404);
```

Зарегистрировать маршрут в `www/api/index.php`:
```php
'push' => __DIR__ . '/routes/push.php',
```

---

### ЗАДАЧА 5 — API: эндпоинт самообновления профиля работника

**Файл:** `www/api/routes/employees.php`

Добавить новый эндпоинт `PATCH /api/employees/{id}/self` — работник редактирует только свои поля:

```php
// PATCH /api/employees/{id}/self — самообновление профиля работником
if ($method === 'PATCH' && $id && $sub === 'self') {
    $user = require_auth();
    // Работник может редактировать только свой профиль
    if ((int)($user['employee_id'] ?? 0) !== $id && ($user['role'] ?? '') === 'worker') {
        json_response(['ok' => false, 'error' => 'Access denied'], 403);
    }
    require_employee_access($user, $id);
    
    $data = read_json();
    // Разрешённые поля для самообновления
    $allowed = ['phone', 'email', 'bank_account', 'bank_iban', 'address', 'emergency_contact', 'emergency_phone', 'notes_self'];
    $updates = [];
    $values = [];
    foreach ($allowed as $field) {
        if (array_key_exists($field, $data)) {
            $updates[] = "`$field` = ?";
            $values[] = $data[$field] === '' ? null : (string)$data[$field];
        }
    }
    if (empty($updates)) {
        json_response(['ok' => false, 'error' => 'No valid fields'], 422);
    }
    $values[] = $id;
    $stmt = db()->prepare("UPDATE employees SET " . implode(', ', $updates) . " WHERE id = ?");
    $stmt->execute($values);
    audit_log($user, 'EMPLOYEE_SELF_UPDATE', 'employees', $id, ['fields' => array_keys(array_intersect_key($data, array_flip($allowed)))]);
    json_response(['ok' => true]);
}
```

---

### ЗАДАЧА 6 — API: очистка истории чата

**Файл:** `www/api/routes/chat.php`

Добавить эндпоинт `DELETE /api/chat/clear`:

```php
// DELETE /api/chat/clear — очистка истории чата
if ($method === 'DELETE' && ($parts[1] ?? '') === 'clear') {
    $user = require_auth();
    $data = read_json();
    $employeeId = isset($data['employee_id']) ? (int)$data['employee_id'] : null;
    $channelKey = isset($data['channel_key']) ? (string)$data['channel_key'] : null;
    
    // Работник может очистить только свой чат
    if (($user['role'] ?? '') === 'worker') {
        $employeeId = (int)($user['employee_id'] ?? 0);
        if (!$employeeId) json_response(['ok' => false, 'error' => 'No employee linked'], 403);
    } else {
        require_permission_check($user, 'chat.write');
        if (!$employeeId) json_response(['ok' => false, 'error' => 'employee_id required'], 422);
    }
    
    $stmt = $channelKey
        ? db()->prepare("DELETE FROM employee_chat_messages WHERE employee_id = ? AND channel_key = ?")
        : db()->prepare("DELETE FROM employee_chat_messages WHERE employee_id = ?");
    
    $params = $channelKey ? [$employeeId, $channelKey] : [$employeeId];
    $stmt->execute($params);
    $deleted = $stmt->rowCount();
    audit_log($user, 'CHAT_CLEAR', 'chat', $employeeId, ['deleted' => $deleted, 'channel' => $channelKey]);
    json_response(['ok' => true, 'deleted' => $deleted]);
}
```

---

### ЗАДАЧА 7 — JS: анимированная кнопка START + таймер на экране блокировки

**Файл:** `www/assets/js/app.js`

#### 7a. Заменить `buildcrew-start-orb` — анимированная кнопка:

Найти все вхождения `<button class=\"buildcrew-start-orb\"` и заменить шаблон:

```javascript
// СТАРЫЙ шаблон:
`<button class="buildcrew-start-orb" type="button" onclick="Pokladna.quickShift('start')">
  <span class="buildcrew-play">START</span>
  <strong>ZACIT</strong>
  <small>spusti smenu a ulozi GPS</small>
</button>`

// НОВЫЙ шаблон (анимированный):
`<button class="buildcrew-start-orb" type="button" onclick="Pokladna.quickShift('start')" aria-label="Spustit smenu">
  <span class="orb-ring orb-ring-1"></span>
  <span class="orb-ring orb-ring-2"></span>
  <span class="orb-ring orb-ring-3"></span>
  <span class="orb-inner">
    <svg width="32" height="32" viewBox="0 0 24 24" fill="currentColor">
      <path d="M8 5v14l11-7z"/>
    </svg>
  </span>
  <strong>ZAČÍT SMĚNU</strong>
  <small>GPS + čas</small>
</button>`
```

#### 7b. MediaSession API — таймер на экране блокировки:

Добавить в функцию `startShiftTimers()` после `shiftTimer = setInterval(tick, 1000);`:

```javascript
// Media Session для экрана блокировки iOS/Android
function updateMediaSession(startTime) {
  if (!('mediaSession' in navigator)) return;
  try {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: 'BuildPay — Směna běží',
      artist: shiftTimerLabel(startTime),
      album: document.querySelector('.buildcrew-object strong')?.textContent?.trim() || 'Práce',
      artwork: [{ src: '/assets/icons/buildpay-192.png', sizes: '192x192', type: 'image/png' }],
    });
    navigator.mediaSession.playbackState = 'playing';
    // Обновлять artist (время) каждую минуту
    clearInterval(window._mediaSessionTimer);
    window._mediaSessionTimer = setInterval(() => {
      if (navigator.mediaSession.metadata) {
        navigator.mediaSession.metadata.artist = shiftTimerLabel(startTime);
      }
    }, 60000);
  } catch (e) { /* ignore */ }
}

// Wake Lock — не гасить экран пока смена активна
async function requestWakeLock() {
  if (!('wakeLock' in navigator)) return;
  try {
    if (window._wakeLock) return;
    window._wakeLock = await navigator.wakeLock.request('screen');
    window._wakeLock.addEventListener('release', () => { window._wakeLock = null; });
  } catch (e) { /* ignore */ }
}

async function releaseWakeLock() {
  if (window._wakeLock) {
    await window._wakeLock.release().catch(() => {});
    window._wakeLock = null;
  }
  clearInterval(window._mediaSessionTimer);
  if ('mediaSession' in navigator) {
    navigator.mediaSession.playbackState = 'none';
  }
}
```

Вызвать `updateMediaSession(timerEl.dataset.shiftStart)` и `requestWakeLock()` в конце `startShiftTimers()` если есть активная смена.  
Вызвать `releaseWakeLock()` в `quickShift('end')` после завершения смены.

#### 7c. Push-уведомления — подписка и отправка:

Добавить функцию `subscribePush()` после `enableNotifications()`:

```javascript
async function subscribePush() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    toast('Push-уведомления не поддерживаются в этом браузере', 'warn');
    return false;
  }
  try {
    const reg = await navigator.serviceWorker.ready;
    // Получить VAPID public key с сервера
    const vapidResp = await api('push/vapid-public').catch(() => null);
    if (!vapidResp?.key) {
      toast('Push-уведомления не настроены на сервере', 'warn');
      return false;
    }
    const sub = await reg.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidResp.key),
    });
    await api('push/subscribe', 'POST', sub.toJSON());
    toast('Push-уведомления включены', 'ok');
    state.notificationsEnabled = true;
    return true;
  } catch (e) {
    toast('Не удалось включить push-уведомления: ' + (e.message || e), 'warn');
    return false;
  }
}

function urlBase64ToUint8Array(base64String) {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  return Uint8Array.from([...rawData].map(c => c.charCodeAt(0)));
}
```

Заменить функцию `enableNotifications()` — теперь она должна запрашивать оба разрешения (Notification + Push):

```javascript
async function enableNotifications() {
  if (!('Notification' in window)) {
    toast('Уведомления не поддерживаются в этом браузере', 'warn');
    return;
  }
  if (Notification.permission === 'default') {
    await Notification.requestPermission();
  }
  state.notificationsEnabled = Notification.permission === 'granted';
  if (state.notificationsEnabled) {
    await subscribePush();
  } else {
    toast('Разрешите уведомления в настройках браузера', 'warn');
  }
}
```

#### 7d. Функция `clearWorkerChat()` — очистка истории чата:

Добавить в объект `Pokladna`:

```javascript
async clearWorkerChat() {
  const employeeId = state.user?.employee_id;
  if (!employeeId) return;
  if (!confirm('Очистить историю чата? Это действие нельзя отменить.')) return;
  const channelKey = document.querySelector('#workerChatThread')?.dataset?.channel || null;
  const r = await api('chat/clear', 'DELETE', { employee_id: employeeId, channel_key: channelKey }).catch(() => null);
  if (r?.ok) {
    const thread = document.getElementById('workerChatThread');
    if (thread) thread.innerHTML = '<div class="empty">История очищена</div>';
    toast('История чата очищена', 'ok');
  } else {
    toast('Ошибка при очистке', 'warn');
  }
},
```

#### 7e. Обновить `buildcrewChatPanel()` — добавить кнопку очистки:

В `buildcrewChatPanel()` добавить кнопку после `.buildcrew-chat-switch`:

```javascript
// Добавить в шаблон buildcrewChatPanel, после buildcrew-chat-switch div:
`<div class="buildcrew-chat-toolbar">
  <button class="btn sm ghost danger" type="button" onclick="Pokladna.clearWorkerChat()" title="Очистить историю">
    ${buildcrewNavIcon('trash')} Очистить историю
  </button>
</div>`
```

#### 7f. Добавить иконку trash в `buildcrewNavIcon()`:

```javascript
// В объект icons добавить:
trash: '<svg viewBox="0 0 24 24" aria-hidden="true"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4h6v2"/></svg>',
```

---

### ЗАДАЧА 8 — JS: профиль работника — редактирование своих данных

**Файл:** `www/assets/js/app.js`

Заменить функцию `buildcrewProfilePanel()` — добавить форму редактирования:

```javascript
function buildcrewProfilePanel(employee, documents = [], options = {}) {
  const docsCount = documents.length ? `${documents.length} dokumentů` : 'žádné dokumenty';
  const passportLabel = employee.passport_valid_until ? `platný do ${employee.passport_valid_until}` : 'nevyplněno';
  const contract = options.contract || employee.contract_type || 'smlouva nevyplněna';

  return `
    <div class="buildcrew-profile-hero">
      ${employeeAvatar(employee, 'xl')}
      <div>
        <strong>${esc(employee.name || state.user?.name || '-')}</strong>
        <span>${esc(employee.company_name || '-')} / ${esc(employee.object_name || '-')}</span>
        <small>${esc(contract)}${options.rate ? ` / ${czk(options.rate)}/h` : ''}</small>
      </div>
    </div>

    <div class="buildcrew-profile-section-title">Moje údaje — upravit</div>
    <form class="buildcrew-field-grid" id="workerSelfEditForm" onsubmit="Pokladna.saveWorkerProfile(event, ${Number(employee.id)})">
      <div class="field">
        <label>Telefon</label>
        <input class="input" type="tel" name="phone" value="${esc(employee.phone || '')}" placeholder="+420...">
      </div>
      <div class="field">
        <label>E-mail</label>
        <input class="input" type="email" name="email" value="${esc(employee.email || '')}" placeholder="vas@email.cz">
      </div>
      <div class="field">
        <label>Číslo účtu (CZ IBAN)</label>
        <input class="input" type="text" name="bank_iban" value="${esc(employee.bank_iban || '')}" placeholder="CZ65 0800 0000 1920 0014 5399">
      </div>
      <div class="field">
        <label>Adresa bydliště</label>
        <input class="input" type="text" name="address" value="${esc(employee.address || '')}" placeholder="Ulice, město">
      </div>
      <div class="field">
        <label>Nouzový kontakt (jméno)</label>
        <input class="input" type="text" name="emergency_contact" value="${esc(employee.emergency_contact || '')}" placeholder="Jméno">
      </div>
      <div class="field">
        <label>Nouzový telefon</label>
        <input class="input" type="tel" name="emergency_phone" value="${esc(employee.emergency_phone || '')}" placeholder="+420...">
      </div>
      <div class="field">
        <label>Poznámka (pro sebe)</label>
        <textarea class="input" name="notes_self" rows="2" placeholder="Vlastní poznámka...">${esc(employee.notes_self || '')}</textarea>
      </div>
      <button class="btn primary" type="submit">Uložit změny</button>
    </form>

    <div class="buildcrew-profile-section-title">Doklady</div>
    <div class="buildcrew-settings-list">
      ${buildcrewSettingRow('file', 'Pas', passportLabel, `onclick="Pokladna.profile(${Number(employee.id)})"`)}
      ${can('documents.view') ? buildcrewSettingRow('file', 'Dokumenty', docsCount, `onclick="Pokladna.documents(${Number(employee.id)})"`) : ''}
      ${can('documents.write') ? buildcrewSettingRow('upload', 'Nahrát dokument', 'pas, pojištění, smlouva', `onclick="Pokladna.documents(${Number(employee.id)})"`) : ''}
    </div>

    <div class="buildcrew-profile-section-title">Nastavení</div>
    <div class="buildcrew-settings-list">
      ${buildcrewSettingRow('bell', 'Upozornění', state.notificationsEnabled ? 'zapnuto' : 'nastavit', `onclick="Pokladna.notifications()"`)}
      ${buildcrewLanguageRow()}
      ${buildcrewSettingRow('lock', 'Heslo', 'změnit přihlášení', `onclick="Pokladna.password()"`)}
    </div>
    <button class="buildcrew-logout-btn" type="button" onclick="Pokladna.logout()">${buildcrewNavIcon('logout')}<span>Odhlásit se</span></button>
  `;
}
```

Добавить в объект `Pokladna`:

```javascript
async saveWorkerProfile(event, employeeId) {
  event.preventDefault();
  const form = event.target;
  const data = Object.fromEntries(new FormData(form));
  const btn = form.querySelector('[type=submit]');
  if (btn) { btn.disabled = true; btn.textContent = 'Ukládám...'; }
  const r = await api(`employees/${employeeId}/self`, 'PATCH', data).catch(() => null);
  if (btn) { btn.disabled = false; btn.textContent = 'Uložit změny'; }
  if (r?.ok) {
    toast('Profil uložen', 'ok');
  } else {
    toast(r?.error || 'Chyba při ukládání', 'warn');
  }
},
```

---

### ЗАДАЧА 9 — CSS: анимированная кнопка START + автовыравнивание мобильного

**Файл:** `www/assets/css/app.css`

Добавить в конец файла:

```css
/* ---- АНИМИРОВАННАЯ КНОПКА START ---- */
.buildcrew-start-orb {
  position: relative;
  width: 200px;
  height: 200px;
  border-radius: 999px;
  border: 0;
  margin: 24px auto 16px;
  display: grid;
  place-items: center;
  align-content: center;
  gap: 4px;
  background: radial-gradient(circle at 50% 35%, #62f0c6 0%, #1fd99a 48%, #0f6645 100%);
  color: #051a10;
  cursor: pointer;
  box-shadow: 0 20px 60px rgba(31,217,154,.4), 0 0 0 1px rgba(31,217,154,.2);
  transition: transform .15s ease, box-shadow .15s ease;
  overflow: visible;
}
.buildcrew-start-orb:hover  { transform: scale(1.04); box-shadow: 0 28px 72px rgba(31,217,154,.52); }
.buildcrew-start-orb:active { transform: scale(.97); }

/* Пульсирующие кольца */
.orb-ring {
  position: absolute;
  inset: 0;
  border-radius: 999px;
  border: 1.5px solid rgba(31,217,154,.45);
  animation: orb-expand 2.4s ease-out infinite;
  pointer-events: none;
}
.orb-ring-1 { animation-delay: 0s; }
.orb-ring-2 { animation-delay: .8s; }
.orb-ring-3 { animation-delay: 1.6s; }

@keyframes orb-expand {
  0%   { transform: scale(1);    opacity: .6; }
  100% { transform: scale(1.55); opacity: 0;  }
}

.orb-inner {
  width: 56px;
  height: 56px;
  border-radius: 999px;
  background: rgba(5,26,16,.15);
  display: grid;
  place-items: center;
  color: #051a10;
  margin-bottom: 4px;
}

.buildcrew-start-orb strong {
  font-size: 15px;
  font-weight: 900;
  color: #051a10;
  letter-spacing: .04em;
}
.buildcrew-start-orb small {
  font-size: 11px;
  color: rgba(5,26,16,.65);
  font-weight: 600;
}

/* ---- МОБИЛЬНОЕ АВТОВЫРАВНИВАНИЕ ---- */
/* Запрет горизонтального скролла */
html, body {
  overflow-x: hidden;
  -webkit-overflow-scrolling: touch;
}

/* Worker shell — полный экран без полосы прокрутки */
.worker-app-shell,
.admin-mobile-shell {
  width: 100dvw;
  min-height: 100dvh;
  overflow-x: hidden;
  -webkit-tap-highlight-color: transparent;
}

/* Контент buildcrew — не шире экрана */
.buildcrew-app {
  max-width: 100%;
  overflow-x: hidden;
}

/* Инпуты — не масштабировать на iOS */
.worker-app-shell input,
.worker-app-shell textarea,
.worker-app-shell select {
  font-size: max(16px, 1em); /* iOS не зумит при font-size >= 16px */
}

/* Форма профиля на мобильном */
#workerSelfEditForm { gap: 12px; }
#workerSelfEditForm .field { margin-bottom: 0; }
#workerSelfEditForm .btn { width: 100%; min-height: 48px; margin-top: 4px; }

/* Chat toolbar */
.buildcrew-chat-toolbar {
  display: flex;
  justify-content: flex-end;
  padding: 4px 0 8px;
}
.buildcrew-chat-toolbar .btn { min-height: 36px; }

/* ---- SAFE AREA / NOTCH ---- */
.worker-app-shell .buildcrew-topbar {
  padding-top: max(14px, env(safe-area-inset-top));
  padding-left:  max(16px, env(safe-area-inset-left));
  padding-right: max(16px, env(safe-area-inset-right));
}
.worker-app-shell .buildcrew-bottom-nav {
  padding-bottom: max(8px, env(safe-area-inset-bottom));
}

/* ---- VIEWPORT META ENFORCEMENT ---- */
/* Контент не шире viewport на маленьких экранах */
* { min-width: 0; }
img, video, iframe { max-width: 100%; }

/* Автоматический размер текста (iOS) */
html {
  -webkit-text-size-adjust: 100%;
  text-size-adjust: 100%;
}

/* Smooth scroll только если нет prefers-reduced-motion */
@media (prefers-reduced-motion: no-preference) {
  html { scroll-behavior: smooth; }
  .buildcrew-app { scroll-behavior: smooth; }
}
```

---

### ЗАДАЧА 10 — Безопасность: критические уязвимости

#### 10a. Добавить поле `notes_self` в таблицу employees

**Файл:** `www/schema.sql`

```sql
-- После колонки notes в таблице employees добавить:
ALTER TABLE employees ADD COLUMN IF NOT EXISTS notes_self TEXT NULL AFTER notes;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS emergency_contact VARCHAR(120) NULL AFTER passport_valid_until;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS emergency_phone VARCHAR(40) NULL AFTER emergency_contact;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS bank_iban VARCHAR(40) NULL AFTER bank_account;
ALTER TABLE employees ADD COLUMN IF NOT EXISTS address TEXT NULL AFTER bank_iban;
```

#### 10b. Rate limiting — ужесточить до 5 попыток

**Файл:** `www/api/routes/auth.php`

Найти `>= 12` → заменить на `>= 5`, интервал оставить 15 минут.

#### 10c. Content-Security-Policy — убрать unsafe-inline для script-src

**Файл:** `www/config/bootstrap.php`

Заменить строку CSP — убрать `'unsafe-inline'` из `script-src`:

```php
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob:; frame-src https://www.openstreetmap.org; connect-src 'self'; form-action 'self'; base-uri 'self'; frame-ancestors 'self'");
```

#### 10d. Audit log — сохранять old_data при UPDATE

**Файл:** `www/config/bootstrap.php` или `www/helpers.php`

В функции `audit_log()` добавить параметр `$old_data = null`:

```php
function audit_log(?array $user, string $action, string $entity, ?int $entityId = null, ?array $newData = null, ?array $oldData = null): void {
    try {
        db()->prepare("INSERT INTO audit_logs (user_id, user_name, action, entity, entity_id, old_data, new_data, ip_address) VALUES (?,?,?,?,?,?,?,?)")
            ->execute([
                $user ? (int)$user['id'] : null,
                $user ? (string)$user['name'] : null,
                $action,
                $entity,
                $entityId,
                $oldData ? json_encode($oldData, JSON_UNESCAPED_UNICODE) : null,
                $newData  ? json_encode($newData,  JSON_UNESCAPED_UNICODE) : null,
                $_SERVER['REMOTE_ADDR'] ?? null,
            ]);
    } catch (Throwable $e) {
        error_log('audit_log error: ' . $e->getMessage());
    }
}
```

#### 10e. Удалить секреты из папки проекта

Добавить `.gitignore` в корень проекта:

```
mysql-meta.json
ftp-meta.json
backups/
*.bak
pass*.txt
private.php
```

#### 10f. Soft-delete для финансовых записей

**Файл:** `www/schema.sql`

```sql
ALTER TABLE advances ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP NULL DEFAULT NULL;
ALTER TABLE payouts  ADD COLUMN IF NOT EXISTS deleted_at TIMESTAMP NULL DEFAULT NULL;
```

Во всех SELECT в `advances.php` и `payouts.php` добавить `AND deleted_at IS NULL`.  
В DELETE-запросах этих маршрутов заменить физическое удаление на `UPDATE ... SET deleted_at = NOW()`.

---

### ЗАДАЧА 11 — HTML `<head>`: viewport + PWA метатеги

**Файл:** `www/index.html` (или генерируется в PHP)

Убедиться что есть:

```html
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1">
<meta name="theme-color" content="#080b11" media="(prefers-color-scheme: dark)">
<meta name="theme-color" content="#080b11">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="BuildPay">
<link rel="apple-touch-startup-image" href="/assets/icons/buildpay-512.png">
```

Добавить `maximum-scale=1` и `viewport-fit=cover` если отсутствуют.

---

## Порядок выполнения

1. Прочитать `PROJECT_STATE.md`
2. Применить `design/app.css` → `www/assets/css/app.css`
3. Обновить `www/schema.sql` (push_subscriptions, new columns, soft-delete)
4. Создать `www/api/routes/push.php`
5. Добавить роут push в `www/api/index.php`
6. Обновить `www/api/routes/auth.php` (rate limit 5)
7. Обновить `www/api/routes/employees.php` (PATCH self)
8. Обновить `www/api/routes/chat.php` (DELETE clear)
9. Обновить `www/config/bootstrap.php` (CSP, audit_log)
10. Обновить `www/assets/js/app.js` (все JS-задачи)
11. Обновить `www/sw.js` (push events)
12. Проверить: `node --check www\assets\js\app.js`
13. Деплой: `powershell -ExecutionPolicy Bypass -File .\deploy-webzdarma.ps1 -RemoteRoot /web`
14. Добавить `.gitignore` в корень

## Правила работы

- Не пересказывай задачи, делай сразу
- После каждого JS-изменения: `node --check www\assets\js\app.js`
- Не трогать `.htaccess`
- FTP root — `/web`, не `/www`
- Обычный пользователь видит ТОЛЬКО свои данные (не менять логику scoping)
- PATCH /employees/{id}/self — только разрешённые поля, строгая проверка ownership
