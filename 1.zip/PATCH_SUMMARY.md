# BuildPay — Патч-сводка для разработчика

## Что делает каждый файл в этом пакете

### `CODEX_PROMPT.md`
Готовый промпт для Claude Codex (Claude Code) — скопируй и вставь.
Codex выполнит все задачи автоматически в правильном порядке.

### `design/app.css`
Новый CSS уже готов. Скопировать в `www/assets/css/app.css`.

---

## Быстрый старт

1. Открой Claude Code (Codex) в терминале:
   ```
   cd C:\Users\huquf\Documents\Codex\2026-05-16\webzdarma-cz
   claude
   ```

2. Скопируй содержимое `CODEX_PROMPT.md` и вставь в чат Codex.

3. Codex сделает всё остальное и задеплоит.

---

## Изменения по файлам

### `www/sw.js`
- Push-уведомления (`push` event)
- Click по уведомлению → открыть приложение
- `pushsubscriptionchange` → переподписка

### `www/schema.sql`
- Новая таблица `push_subscriptions`
- Новые колонки в `employees`: `notes_self`, `emergency_contact`, `emergency_phone`, `bank_iban`, `address`
- Soft-delete в `advances` и `payouts`: колонка `deleted_at`

### `www/api/routes/push.php` (новый файл)
- `POST /api/push/subscribe` — сохранить push-подписку
- `DELETE /api/push/subscribe` — удалить
- `GET /api/push/vapid-public` — получить публичный ключ

### `www/api/index.php`
- Добавить роут `'push'`

### `www/api/routes/auth.php`
- Rate limit: 12 → **5** попыток за 15 минут

### `www/api/routes/employees.php`
- `PATCH /api/employees/{id}/self` — работник редактирует: phone, email, bank_iban, address, emergency_contact, emergency_phone, notes_self

### `www/api/routes/chat.php`
- `DELETE /api/chat/clear` — очистка истории (работник своей, админ любой)

### `www/config/bootstrap.php`
- CSP: убрать `'unsafe-inline'` из `script-src`
- `audit_log()`: добавить параметр `$old_data`

### `www/assets/js/app.js`
- **Кнопка START**: анимированные пульсирующие кольца (`.orb-ring`)
- **MediaSession API**: таймер + название смены на экране блокировки iPhone/Android
- **Wake Lock API**: экран не гаснет пока смена активна
- **Push-подписка**: `subscribePush()`, `urlBase64ToUint8Array()`
- **Очистка чата**: `clearWorkerChat()` + кнопка в панели чата + иконка `trash`
- **Профиль работника**: форма саморедактирования + `saveWorkerProfile()`

### `www/assets/css/app.css`
- Анимация кнопки START (`.orb-ring`, `@keyframes orb-expand`)
- Мобильное автовыравнивание (`overflow-x: hidden`, `dvw/dvh`, `safe-area-inset`)
- iOS no-zoom на инпутах (`font-size: max(16px, 1em)`)
- Форма профиля `#workerSelfEditForm`
- Chat toolbar `.buildcrew-chat-toolbar`

### `www/index.html` (или PHP-шаблон)
- viewport: добавить `viewport-fit=cover`, `maximum-scale=1`
- Apple PWA метатеги для статус-бара

### `.gitignore` (новый файл в корне)
- Исключить `mysql-meta.json`, `ftp-meta.json`, `backups/`, `pass*.txt`
