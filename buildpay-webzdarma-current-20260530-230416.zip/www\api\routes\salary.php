<?php
declare(strict_types=1);

$method = request_method();
$parts = explode('/', request_path());
$action = $parts[1] ?? '';
$sub = $parts[2] ?? '';

function salary_money(float $value): string
{
    return number_format($value, 2, ',', ' ') . ' Kc';
}

function salary_num(float $value): string
{
    return number_format($value, 2, ',', ' ');
}

function salary_print_css(): string
{
    return 'body{font:13px Arial,sans-serif;color:#111;margin:28px}button{margin-bottom:14px}h1{margin:0 0 6px;font-size:22px}h2{margin:20px 0 8px;font-size:16px}.meta{color:#555;margin-bottom:18px}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:14px 0}.box{border:1px solid #999;padding:8px}.box span{display:block;color:#666;font-size:11px;text-transform:uppercase}.box strong{display:block;font-size:15px;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:8px}th,td{border:1px solid #999;padding:7px;text-align:left;vertical-align:top}th{background:#eee}.num{text-align:right}.sign{height:38px}@media print{button{display:none}body{margin:12mm}.grid{break-inside:avoid}}';
}

function salary_print_header(string $title, int $month, int $year): void
{
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="cs"><head><meta charset="utf-8"><title>' . htmlspecialchars($title) . '</title>';
    echo '<style>' . salary_print_css() . '</style></head><body>';
    echo '<button onclick="window.print()">Tisk</button>';
    echo '<h1>' . htmlspecialchars($title) . '</h1>';
    echo '<div class="meta">Obdobi: ' . htmlspecialchars((string)$month) . '/' . htmlspecialchars((string)$year) . ' | Vytvoreno: ' . date('d.m.Y H:i') . '</div>';
}

function salary_print_box(string $label, string $value): string
{
    return '<div class="box"><span>' . htmlspecialchars($label) . '</span><strong>' . htmlspecialchars($value) . '</strong></div>';
}

function salary_print_person(array $row, int $month, int $year): void
{
    salary_print_header('Mzdova karta pracovnika: ' . (string)$row['employee_name'], $month, $year);
    echo '<div class="grid">';
    echo salary_print_box('Pracovnik', (string)$row['employee_name']);
    echo salary_print_box('Firma / objekt', trim((string)($row['company_name'] ?? '') . ' / ' . (string)($row['object_name'] ?? ''), ' /'));
    echo salary_print_box('Bydleni', (string)($row['accommodation_name'] ?? '-'));
    echo salary_print_box('Bankovni ucet', (string)($row['bank_account'] ?? '-'));
    echo salary_print_box('Zdroj hodin', (string)($row['source'] ?? '-'));
    echo salary_print_box('Hodiny', salary_num((float)$row['hours']) . ' + bonus ' . salary_num((float)($row['bonus_hours'] ?? 0)));
    echo salary_print_box('Hodiny k vyplate', salary_num((float)$row['payable_hours']));
    echo salary_print_box('Sazba', salary_money((float)$row['hourly_rate']));
    echo salary_print_box('Hrube', salary_money((float)$row['gross']));
    echo salary_print_box('Bonus / srazka', salary_money((float)$row['bonus_amount']) . ' / ' . salary_money((float)$row['deduction_amount']));
    echo salary_print_box('Zalohy', salary_money((float)$row['advances']) . ' (zadosti ' . salary_money((float)($row['approved_advances'] ?? 0)) . ', rucne ' . salary_money((float)($row['manual_advances'] ?? 0)) . ')');
    echo salary_print_box('Bydleni srazka', salary_money((float)$row['housing']));
    echo salary_print_box('Bonus pojisteni', salary_money((float)($row['insurance_amount'] ?? 0)));
    echo salary_print_box('K vyplate', salary_money((float)$row['net']));
    echo salary_print_box('Karta', salary_money((float)($row['card_amount'] ?? 0)));
    echo salary_print_box('Hotovost', salary_money((float)($row['cash_amount'] ?? 0)));
    echo salary_print_box('Zustava', salary_money((float)($row['remains'] ?? 0)));
    echo '</div>';
    echo '<h2>Detail vypoctu</h2>';
    echo '<table><thead><tr><th>Popis</th><th class="num">Castka / hodnota</th></tr></thead><tbody>';
    $details = [
        ['Hodiny', salary_num((float)$row['hours'])],
        ['Bonus hodiny', salary_num((float)($row['bonus_hours'] ?? 0))],
        ['Hodiny k vyplate', salary_num((float)$row['payable_hours'])],
        ['Sazba', salary_money((float)$row['hourly_rate'])],
        ['Hrube', salary_money((float)$row['gross'])],
        ['Bonusy', salary_money((float)$row['bonus_amount'])],
        ['Srazky', salary_money((float)$row['deduction_amount'])],
        ['Zalohy celkem', salary_money((float)$row['advances'])],
        ['Bydleni', salary_money((float)$row['housing'])],
        ['Bonus pojisteni', salary_money((float)($row['insurance_amount'] ?? 0))],
        ['Final k vyplate', salary_money((float)$row['net'])],
    ];
    foreach ($details as $detail) {
        echo '<tr><td>' . htmlspecialchars($detail[0]) . '</td><td class="num">' . htmlspecialchars($detail[1]) . '</td></tr>';
    }
    echo '</tbody></table><h2>Podpis</h2><table><tr><td class="sign">Pracovnik</td><td class="sign">Administrator</td></tr></table></body></html>';
    exit;
}

function salary_print_all(array $rows, array $totals, int $month, int $year): void
{
    salary_print_header('Souhrn mezd a vydaju na pracovniky', $month, $year);
    echo '<div class="grid">';
    echo salary_print_box('Hrube', salary_money((float)$totals['gross']));
    echo salary_print_box('Bonusy', salary_money((float)$totals['bonus_amount']));
    echo salary_print_box('Srazky', salary_money((float)$totals['deduction_amount']));
    echo salary_print_box('Zalohy', salary_money((float)$totals['advances']));
    echo salary_print_box('Bydleni', salary_money((float)$totals['housing']));
    echo salary_print_box('Bonus pojisteni', salary_money((float)($totals['insurance_amount'] ?? 0)));
    echo salary_print_box('Final k vyplate', salary_money((float)$totals['net']));
    echo salary_print_box('Odeslat na kartu', salary_money((float)$totals['card_amount']));
    echo salary_print_box('Hotovost', salary_money((float)$totals['cash_amount']));
    echo salary_print_box('Zustava', salary_money((float)$totals['remains']));
    echo '</div>';
    echo '<h2>Pracovnici</h2>';
    echo '<table><thead><tr><th>Pracovnik</th><th>Firma</th><th>Objekt</th><th>Bydleni</th><th class="num">Hodiny</th><th class="num">Sazba</th><th class="num">Hrube</th><th class="num">Bonusy</th><th class="num">Srazky</th><th class="num">Zalohy</th><th class="num">Bydleni</th><th class="num">Bonus pojisteni</th><th class="num">K vyplate</th><th class="num">Karta</th><th class="num">Hotovost</th><th class="num">Zustava</th></tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr><td>' . htmlspecialchars((string)$row['employee_name']) . '<br><small>' . htmlspecialchars((string)($row['bank_account'] ?? '')) . '</small></td>';
        echo '<td>' . htmlspecialchars((string)($row['company_name'] ?? '')) . '</td>';
        echo '<td>' . htmlspecialchars((string)($row['object_name'] ?? '')) . '</td>';
        echo '<td>' . htmlspecialchars((string)($row['accommodation_name'] ?? '')) . '</td>';
        echo '<td class="num">' . salary_num((float)$row['payable_hours']) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['hourly_rate']) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['gross']) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['bonus_amount']) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['deduction_amount']) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['advances']) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['housing']) . '</td>';
        echo '<td class="num">' . salary_money((float)($row['insurance_amount'] ?? 0)) . '</td>';
        echo '<td class="num">' . salary_money((float)$row['net']) . '</td>';
        echo '<td class="num">' . salary_money((float)($row['card_amount'] ?? 0)) . '</td>';
        echo '<td class="num">' . salary_money((float)($row['cash_amount'] ?? 0)) . '</td>';
        echo '<td class="num">' . salary_money((float)($row['remains'] ?? 0)) . '</td></tr>';
    }
    echo '</tbody><tfoot><tr><th colspan="6">Celkem</th><th class="num">' . salary_money((float)$totals['gross']) . '</th><th class="num">' . salary_money((float)$totals['bonus_amount']) . '</th><th class="num">' . salary_money((float)$totals['deduction_amount']) . '</th><th class="num">' . salary_money((float)$totals['advances']) . '</th><th class="num">' . salary_money((float)$totals['housing']) . '</th><th class="num">' . salary_money((float)($totals['insurance_amount'] ?? 0)) . '</th><th class="num">' . salary_money((float)$totals['net']) . '</th><th class="num">' . salary_money((float)$totals['card_amount']) . '</th><th class="num">' . salary_money((float)$totals['cash_amount']) . '</th><th class="num">' . salary_money((float)$totals['remains']) . '</th></tr></tfoot></table></body></html>';
    exit;
}

$user = require_permission('salary.view');
$month = (int)($_GET['month'] ?? date('n'));
$year = (int)($_GET['year'] ?? date('Y'));

if ($method === 'GET' && $action === 'print') {
    $rows = payroll_rows($month, $year, $user, true);
    $totals = payroll_totals($rows, ['gross', 'bonus_amount', 'deduction_amount', 'advances', 'housing', 'insurance_amount', 'net', 'card_amount', 'cash_amount', 'remains']);
    salary_print_all($rows, $totals, $month, $year);
}

if ($method === 'GET' && is_numeric($action) && $sub === 'print') {
    $employeeId = (int)$action;
    $rows = payroll_rows($month, $year, $user, true);
    foreach ($rows as $row) {
        if ((int)$row['employee_id'] === $employeeId) {
            salary_print_person($row, $month, $year);
        }
    }
    json_response(['ok' => false, 'error' => 'Employee salary row not found'], 404);
}

$rows = payroll_rows($month, $year, $user, true);
$stavbaRows = payroll_stavba_rows($month, $year, $user, true);
$totals = payroll_totals($rows, ['hours', 'bonus_hours', 'payable_hours', 'gross', 'bonus_amount', 'deduction_amount', 'advances', 'housing', 'insurance_amount', 'net', 'card_amount', 'cash_amount', 'remains']);
$stavbaTotals = payroll_totals($stavbaRows, ['checkin_hours', 'timesheet_hours', 'manual_hours', 'payable_hours', 'gross', 'bonus_amount', 'deduction_amount', 'advances', 'housing', 'insurance_amount', 'net', 'card_amount', 'cash_amount', 'remains']);

json_response(['ok' => true, 'data' => $rows, 'totals' => $totals, 'stavba' => $stavbaRows, 'stavba_totals' => $stavbaTotals]);
