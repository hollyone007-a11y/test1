<?php
return [
    'db_host' => 'sql5.webzdarma.cz',
    'db_name' => 'pokladnakval1837',
    'db_user' => 'pokladnakval1837',
    'db_pass' => 'Px9!kV7sQ2m#Z4rT',
    'app_url' => 'http://pokladna.kvalitne.cz',
    'app_secret' => 'ZxfLaHFR+h7DEKdUxqr8PpGV42PnS2fR2rgYdB3zSu8=',
    'install_key' => 'H7ioeHUDY2arLLC8AOUnnWT8',
    'admin_email' => 'admin@pokladna.cz',
    'admin_password' => 'Pokladna2026!',
];