const CACHE_NAME = 'buildpay-shell-20260528-0121';
const SHELL = [
  '/',
  '/index.html',
  '/assets/css/app.css?v=20260528-0121',
  '/assets/js/app.js?v=20260528-0121',
  '/assets/icons/buildpay-192.png',
  '/assets/icons/buildpay-512.png',
  '/assets/icons/buildpay.svg'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || new URL(request.url).pathname.startsWith('/api/')) {
    return;
  }
  event.respondWith(fetch(request).then(response => {
    const copy = response.clone();
    caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(() => {});
    return response;
  }).catch(() => caches.match(request).then(cached => cached || caches.match('/'))));
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  event.waitUntil(clients.matchAll({ type: 'window', includeUncontrolled: true }).then(windows => {
    const existing = windows.find(client => client.url.includes(self.location.origin));
    return existing ? existing.focus() : clients.openWindow('/');
  }));
});
